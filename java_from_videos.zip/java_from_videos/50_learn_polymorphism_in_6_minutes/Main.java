public class Main {
    public static void main(String[] args) {

        // Polymorphism = "POLY-" = "MANY"
        //                               "-MORPH" = "SHAPE"

        Car car = new Car();
        Bike bike = new Bike();
        Boat boat = new Boat();

        Vehicle[] vehicles = {car, bike, boat};

        for(Vehicle vehicle : vehicles){
            vehicle.go();
        }
    }
}
public abstract class Vehicle {

    abstract void go();
}
public class Car extends Vehicle{

    @Override
    void go(){
        System.out.println("You drive the car");
    }
}
public class Bike extends Vehicle{

    @Override
    void go(){
        System.out.println("You ride the bike");
    }
}
public class Boat extends Vehicle{

    @Override
    void go(){
        System.out.println("You sail the boat");
    }
}
