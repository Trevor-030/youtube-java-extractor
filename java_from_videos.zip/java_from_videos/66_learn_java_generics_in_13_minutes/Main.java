// NOTE: wrapped in a class by the extractor
public class Main {
    public static void main(String[] args) {
        // Generics = A concept where you can write a class, interface, or method
        //                     that is compatible with different data types.
        //                     type parameter (placeholder that gets replaced with a real type)
        //                     type argument (specifies the type)
    }
}
